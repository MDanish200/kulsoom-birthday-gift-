# Kulsoom Birthday Gift

A mobile-friendly birthday surprise website personalized for Syeda Kulsoom by Muhammad Danish.

## Included
- Birthday countdown to October 17, 2026 (Pakistan time)
- Four-digit PIN gate (`2010`)
- Five aesthetic memory cards without faces
- English birthday letter
- Responsive layout for phones and desktop

## Preview on iPhone
Unzip the project in the Files app. To publish, upload the files to your own GitHub repository and enable GitHub Pages.

## Publish with GitHub Pages
1. Sign in at https://github.com and create a new public repository, e.g. `kulsoom-birthday-gift`.
2. Upload `index.html`, `style.css`, `script.js`, and `README.md` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/(root)`, then Save.
5. After GitHub Pages finishes deploying, use the URL shown in Settings → Pages.

## Edit the PIN or date
Open `script.js` and edit `TARGET_PASSCODE` or `BIRTHDAY`.
Note: this PIN is a playful gate, not real security. Anyone who can inspect the public JavaScript can find it. Do not put private information in a public repository.

## About the visuals
The starter version uses emoji illustrations and CSS gradients, so it does not depend on third-party character artwork. Replace the memory cards with properly licensed images if you want actual photos.
