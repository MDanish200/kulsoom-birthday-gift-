// Personalize these settings for your birthday surprise.
const TARGET_PASSCODE = "2010";
const BIRTHDAY = new Date("2026-10-17T00:00:00+05:00");

const $ = (id) => document.getElementById(id);
function updateCountdown() {
  const now = new Date();
  let diff = BIRTHDAY.getTime() - now.getTime();
  if (diff <= 0) {
    $("date-note").textContent = "Today is your special day — happy birthday, Kulsoom! 🎂";
    $("days").textContent = "00";
    $("hours").textContent = "00";
    $("minutes").textContent = "00";
    $("seconds").textContent = "00";
    return;
  }
  const days = Math.floor(diff / 86400000); diff %= 86400000;
  const hours = Math.floor(diff / 3600000); diff %= 3600000;
  const minutes = Math.floor(diff / 60000); diff %= 60000;
  const seconds = Math.floor(diff / 1000);
  $("days").textContent = String(days).padStart(2,"0");
  $("hours").textContent = String(hours).padStart(2,"0");
  $("minutes").textContent = String(minutes).padStart(2,"0");
  $("seconds").textContent = String(seconds).padStart(2,"0");
}
updateCountdown();
setInterval(updateCountdown, 1000);

$("open-gift").addEventListener("click", () => {
  $("gift-area").classList.remove("hidden");
  $("gift-area").scrollIntoView({behavior:"smooth",block:"center"});
  $("pin").focus({preventScroll:true});
});
$("pin-form").addEventListener("submit", (event) => {
  event.preventDefault();
  if ($("pin").value === TARGET_PASSCODE) {
    $("pin-message").textContent = "Unlocked! This little world is all yours. ♡";
    $("memories").classList.remove("hidden");
    $("letter").classList.add("hidden");
    $("memories").scrollIntoView({behavior:"smooth",block:"start"});
  } else {
    $("pin-message").textContent = "Not quite, sweetheart. Try again. 💗";
    $("pin").value = "";
    $("pin").focus();
  }
});
$("read-letter").addEventListener("click", () => {
  $("letter").classList.remove("hidden");
  $("letter").scrollIntoView({behavior:"smooth",block:"start"});
});
$("again").addEventListener("click", () => {
  $("letter").classList.add("hidden");
  $("memories").classList.add("hidden");
  $("gift-area").classList.add("hidden");
  $("pin").value = "";
  $("pin-message").textContent = "";
  window.scrollTo({top:0,behavior:"smooth"});
});
